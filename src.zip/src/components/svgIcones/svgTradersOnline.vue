<template>
<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"><path d="M7 7a3.5 3.5 0 1 0-3.5-3.5A3.5 3.5 0 0 0 7 7zm0 1.75c-2.335 0-7 1.173-7 3.5V14h14v-1.75C14 9.924 9.334 8.75 7 8.75z" class="svgDashIcon"/></svg>
</template>
<style scoped>
		.svgDashIcon{
		fill:#6968ff; 
		fill-rule:evenodd
	}
	.router-link-active .svgDashIcon{
		fill: #fff;
	}
</style>