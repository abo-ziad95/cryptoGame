<template>
<svg xmlns="http://www.w3.org/2000/svg" width="14" height="15"><path d="M8.7 1.483L8.528.255a.3.3 0 0 0-.3-.257h-2.44a.3.3 0 0 0-.3.255L5.3 1.48a7 7 0 1 0 3.39.002zm2.842 8.124l-.293.787a.507.507 0 0 1-.647.3L6.068 9.078V4.354a.5.5 0 0 1 .505-.5h.856a.5.5 0 0 1 .505.5V7.8l3.306 1.177a.493.493 0 0 1 .301.63z" class="svgDashIcon"/></svg>
</template>
<style scoped>
		.svgDashIcon{
		fill:#6968ff; 
		fill-rule:evenodd
	}
	.router-link-active .svgDashIcon{
		fill: #fff;
	}
</style>