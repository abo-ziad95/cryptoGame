<template>
<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"><path d="M15 .54v12.516a.5.5 0 0 1-.931.295c-1.553-2.54-1.83-3.717-7.216-4l.44 5.65H4.75L3.03 9.13C1.346 9.05.001 8.588.001 6.8c0-1.84 1.423-2.34 3.177-2.34 7.388 0 9.125-1.327 10.888-4.214A.5.5 0 0 1 15 .54z" class="svgDashIcon"/></svg>
</template>
<style scoped>
		.svgDashIcon{
		fill:#6968ff; 
		fill-rule:evenodd
	}
	.router-link-active .svgDashIcon{
		fill: #fff;
	}
</style>