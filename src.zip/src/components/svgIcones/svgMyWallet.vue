<template>
<svg xmlns="http://www.w3.org/2000/svg" width="17" height="13"><path d="M1.033 0A1.014 1.014 0 0 0 .007 1v11.014a1.014 1.014 0 0 0 1.026 1H15.58a1.014 1.014 0 0 0 1.025-1v-.5H8.04a1.014 1.014 0 0 1-1.026-1V2.5a1.015 1.015 0 0 1 1.026-1h8.566V1a1.013 1.013 0 0 0-1.025-1H1.033zm7.915 4a1.013 1.013 0 0 1 1.026-1h6A1.013 1.013 0 0 1 17 4v5a1.013 1.013 0 0 1-1.026 1h-6a1.013 1.013 0 0 1-1.026-1V4zm2.532 1.213a.507.507 0 0 0-.513.5V7.3a.507.507 0 0 0 .513.5h1.447a.506.506 0 0 0 .512-.5v-1.587a.506.506 0 0 0-.512-.5H11.48z" class="svgDashIcon"/></svg>
</template>
<style scoped>
		.svgDashIcon{
		fill:#6968ff; 
		fill-rule:evenodd
	}
	.router-link-active .svgDashIcon{
		fill: #fff;
	}
</style>