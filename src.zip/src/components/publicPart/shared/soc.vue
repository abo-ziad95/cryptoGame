<template>
	<div class="soc">
		<a href="#" class="soc-link"> <img src="../../../images/public-part/footer/fb.png" alt="#"> </a>
		<a href="#" class="soc-link"> <img src="../../../images/public-part/footer/fb.png" alt="#"> </a>
		<a href="#" class="soc-link"> <img src="../../../images/public-part/footer/fb.png" alt="#"> </a>
	</div>
</template>
<style scoped>
.soc{
	display: flex;
	align-items: center;
	max-width: 200px;
	width: 100%;
}
.soc-link{
	border: 1px solid #2c2f34;
	border-radius: 100%;
	display: flex;
	align-items: center;
	justify-content: center;
	width: 40px;
	height: 40px;
	margin: 0 15px 0 0;
}
</style>