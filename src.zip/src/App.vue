<template>
  <div class="container">
    <router-view></router-view>  
  </div>
</template>

<script>

export default {

}
</script>
<style>
  @import "./styles/reset.css";
</style>
<style>
  @import "./styles/fonts.css";
</style>
<style scoped>
.container{
  position: relative;
}
.row{
  display: flex;
}
</style>
